score = int(input("score:"))
grade =""
if score >= 70 :
    grade = "G"
elif score >=50 :
    grade = "P"
else :
    grade = "F"
    
print ("score =", score)
print ("grade is", grade)        
