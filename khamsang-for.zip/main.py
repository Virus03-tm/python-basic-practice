total = 0
for i in range(10, 31) :
    if i %2 == 1 :
        total = total + i
        
print ('total = ', total)
